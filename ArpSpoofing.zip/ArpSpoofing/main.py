from ScanIPs import ScanIPs
from SendARP import SendARP
import sys
import time

def args_handler():
    """Handle command line arguments."""
    if len(sys.argv) != 5:
        return None, None, None, None
    return sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]


def set_args(_SendARP: SendARP):
    """Set ARP parameters interactively."""
    arg_names = ['target_ip', 'gateway_ip', 'target_mac', 'gateway_mac']
    
    for arg in arg_names:
        value = input(f"Enter {arg.replace('_', ' ')}: ")
        if arg.endswith('_ip'):
            setattr(_SendARP, arg, [value])
        else:
            setattr(_SendARP, arg, [value.lower()])


def main():
    """Main function that integrates scanning and ARP sending."""
    print("=== Network Scanner and ARP Tool ===")
    print("Starting network monitoring...")
    
    # Initialize scanner
    scanner = ScanIPs()
    
    # Start ARP scanning
    result = scanner.scan_arp_packet()
    print(result)
    
    try:
        # Let it scan for a bit
        print("\nPress Ctrl+C to stop scanning and proceed to ARP sending options...")
        time.sleep(5)  # Give some time to see ARP requests
        
        # Check for detected ARP requests
        if scanner.arp_requests_detected:
            print(f"\n🎯 Detected {len(scanner.arp_requests_detected)} ARP broadcast requests!")
            print("\nRecent ARP requests:")
            for req in scanner.arp_requests_detected[-5:]:  # Show last 5
                print(f"  {req['src_ip']} ({req['src_mac']}) looking for {req['dst_ip']}")
        
        # Ask user about SendARP
        print("\n" + "="*50)
        use_sendarp = input("Do you want to use the SendARP class? (y/n): ").lower().strip()
        
        if use_sendarp in ['y', 'yes']:
            # Stop scanning first
            scanner.stop_scanning()
            
            # Check command line arguments
            target_ip, gateway_ip, target_mac, gateway_mac = args_handler()
            
            # Initialize SendARP
            _SendARP = SendARP()
            
            if all([target_ip, gateway_ip, target_mac, gateway_mac]):
                print("Using command line arguments...")
                _SendARP.__init__(
                    target_ip=target_ip,
                    gateway_ip=gateway_ip,
                    target_mac=target_mac,
                    gateway_mac=gateway_mac
                )
            else:
                print("No command line arguments provided. Please enter manually:")
                set_args(_SendARP)
            
            # Send ARP requests
            response = None
            attempts = 0
            max_attempts = 3
            
            while response is None and attempts < max_attempts:
                print(f"\nAttempt {attempts + 1}/{max_attempts} - Sending ARP request...")
                response = _SendARP.send_arp()
                attempts += 1
                
                if response is None and attempts < max_attempts:
                    print("Failed to send ARP request. Retrying...")
                    time.sleep(1)
            
            if response is None:
                print("Failed to send ARP request after multiple attempts.")
            else:
                print("ARP request sent successfully!")
        
        else:
            print("Continuing with network scanning...")
            input("Press Enter to stop scanning...")
            
    except KeyboardInterrupt:
        print("\n\nStopping network scan...")
    finally:
        scanner.stop_scanning()
        scanner.print_discovered_devices()
        print("\nProgram terminated.")


if __name__ == "__main__":
    main()