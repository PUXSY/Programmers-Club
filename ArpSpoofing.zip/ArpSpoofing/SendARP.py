import socket
import threading
import time
import sys
from scapy.all import *
from scapy.layers.l2 import ARP, Ether
from scapy.layers.inet import IP, ICMP


global target_ip, gateway_ip, target_mac, gateway_mac
broadcast_mac = "ff:ff:ff:ff:ff:ff"


class SendARP:
    def __init__(self, target_ip: str = "", gateway_ip: str = "", target_mac: str = "", gateway_mac: str = ""):
        if target_ip:
            self.target_ip = target_ip.split(' ') if ' ' in target_ip else [target_ip]
            self.gateway_ip = gateway_ip.split(' ') if ' ' in gateway_ip else [gateway_ip]
            self.target_mac = target_mac.lower().split(' ') if ' ' in target_mac else [target_mac.lower()]
            self.gateway_mac = gateway_mac.lower().split(' ') if ' ' in gateway_mac else [gateway_mac.lower()]
        else:
            self.target_ip = []
            self.gateway_ip = []
            self.target_mac = []
            self.gateway_mac = []

    def send_arp(self):
        """Send ARP request(s) to target(s)."""
        if not all([self.target_ip, self.gateway_ip, self.target_mac, self.gateway_mac]):
            print("Error: Missing required parameters for ARP request")
            return None
        
        # Handle multiple targets
        for i in range(len(self.target_ip)):
            target_ip = self.target_ip[i] if i < len(self.target_ip) else self.target_ip[0]
            gateway_ip = self.gateway_ip[i] if i < len(self.gateway_ip) else self.gateway_ip[0]
            target_mac = self.target_mac[i] if i < len(self.target_mac) else self.target_mac[0]
            gateway_mac = self.gateway_mac[i] if i < len(self.gateway_mac) else self.gateway_mac[0]
            
            arp_request = Ether(dst=broadcast_mac) / ARP(
                op=1, 
                psrc=gateway_ip, 
                pdst=target_ip, 
                hwsrc=gateway_mac, 
                hwdst=target_mac
            )   
            
            try:
                response = sendp(arp_request, verbose=False, timeout=2)
                print(f"ARP request sent to {target_ip} from {gateway_ip}")
                print(f"Target MAC: {target_mac}, Gateway MAC: {gateway_mac}")
                return response
            except Exception as e:
                print(f"Error sending ARP request: {e}")
                return None