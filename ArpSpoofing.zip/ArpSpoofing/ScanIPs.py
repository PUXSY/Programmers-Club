import threading
from scapy.all import *
from scapy.layers.l2 import ARP, Ether
from scapy.layers.inet import IP, ICMP

class ScanIPs:
    def __init__(self):
        # [(IP, MAC), NAME]
        self.ipsList: dict[tuple[str, str], str] = {}
        self.scanning = False
        self.scan_thread = None
        self.arp_requests_detected = []
        
    def scan_arp_packet(self) -> str:
        """
        Continuously scan for ARP packets on the network.
        Captures ARP requests, replies, and broadcasts.
        Returns status message.
        """
        try:
            if self.scanning:
                return "Scanning already in progress"
            
            self.scanning = True
            print("Starting ARP packet scanning...")
            print("Monitoring network for ARP requests...")
            print("-" * 50)
            
            def packet_handler(packet):
                if packet.haslayer(ARP):
                    arp_layer = packet[ARP]
                    
                    # Process ARP requests (who-has) - Broadcast requests
                    if arp_layer.op == 1:  # ARP request
                        src_ip = arp_layer.psrc
                        src_mac = arp_layer.hwsrc
                        dst_ip = arp_layer.pdst
                        
                        # Check if it's a broadcast request
                        if packet.haslayer(Ether) and packet[Ether].dst == "ff:ff:ff:ff:ff:ff":
                            print(f"🔍 BROADCAST ARP REQUEST DETECTED:")
                            print(f"   Source IP: {src_ip}")
                            print(f"   Source MAC: {src_mac}")
                            print(f"   Looking for: {dst_ip}")
                            print(f"   Time: {time.strftime('%H:%M:%S')}")
                            print("-" * 50)
                            
                            # Store the request
                            self.arp_requests_detected.append({
                                'src_ip': src_ip,
                                'src_mac': src_mac,
                                'dst_ip': dst_ip,
                                'timestamp': time.time()
                            })
                        
                        self._add_device_to_list(src_ip, src_mac)
                    
                    # Process ARP replies (is-at)
                    elif arp_layer.op == 2:  # ARP reply
                        src_ip = arp_layer.psrc
                        src_mac = arp_layer.hwsrc
                        dst_ip = arp_layer.pdst
                        dst_mac = arp_layer.hwdst
                        
                        print(f"📡 ARP Reply: {src_ip} is at {src_mac}")
                        self._add_device_to_list(src_ip, src_mac)
                        if dst_ip and dst_mac:
                            self._add_device_to_list(dst_ip, dst_mac)
            
            # Start packet capture in a separate thread
            self.scan_thread = threading.Thread(
                target=lambda: sniff(filter="arp", prn=packet_handler, stop_filter=lambda x: not self.scanning)
            )
            self.scan_thread.daemon = True
            self.scan_thread.start()
            
            return "ARP scanning started successfully"
            
        except Exception as e:
            self.scanning = False
            return f"Error starting ARP scan: {str(e)}"
    
    def stop_scanning(self):
        """Stop the ARP packet scanning"""
        self.scanning = False
        if self.scan_thread:
            self.scan_thread.join(timeout=2)
        print("\nARP scanning stopped")
    
    def get_ip_from_scan(self, arp_packet: str) -> str:
        """Extract IP address from ARP packet string representation."""
        try:
            if isinstance(arp_packet, str):
                import re
                ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
                ips = re.findall(ip_pattern, arp_packet)
                if ips:
                    return ips[0]
            elif hasattr(arp_packet, 'haslayer') and arp_packet.haslayer(ARP):
                return arp_packet[ARP].psrc
            return ""
        except Exception as e:
            print(f"Error extracting IP: {str(e)}")
            return ""
    
    def get_mac_from_scan(self, arp_packet: str) -> str:
        """Extract MAC address from ARP packet string representation."""
        try:
            if isinstance(arp_packet, str):
                import re
                mac_pattern = r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})'
                macs = re.findall(mac_pattern, arp_packet)
                if macs:
                    return ''.join(macs[0])
            elif hasattr(arp_packet, 'haslayer') and arp_packet.haslayer(ARP):
                return arp_packet[ARP].hwsrc
            return ""
        except Exception as e:
            print(f"Error extracting MAC: {str(e)}")
            return ""
    
    def add_ip_to_list(self, ip: str, mac: str = "", name: str = "") -> None:
        """Add IP address to the list with optional MAC and name."""
        try:
            if not mac:
                mac = self._get_mac_for_ip(ip)
            if not name:
                name = self._resolve_hostname(ip)
            key = (ip, mac)
            self.ipsList[key] = name
        except Exception as e:
            print(f"Error adding IP to list: {str(e)}")
    
    def add_mac_to_list(self, mac: str, ip: str = "", name: str = "") -> None:
        """Add MAC address to the list with optional IP and name."""
        try:
            if not ip:
                ip = self._get_ip_for_mac(mac)
            if not name:
                name = self._resolve_hostname(ip) if ip else f"Device-{mac[:8]}"
            key = (ip, mac)
            self.ipsList[key] = name
        except Exception as e:
            print(f"Error adding MAC to list: {str(e)}")
    
    def _add_device_to_list(self, ip: str, mac: str) -> None:
        """Internal method to add device to list with hostname resolution."""
        if ip and mac:
            name = self._resolve_hostname(ip)
            key = (ip, mac)
            if key not in self.ipsList:
                self.ipsList[key] = name
    
    def get_ip_mac(self, ip: str) -> tuple[str, str]:
        """Returns a tuple of (IP, MAC) for the given IP address."""
        try:
            for (stored_ip, mac), name in self.ipsList.items():
                if stored_ip == ip:
                    return (stored_ip, mac)
            mac = self._get_mac_for_ip(ip)
            if mac:
                return (ip, mac)
            return ("", "")
        except Exception as e:
            print(f"Error getting IP/MAC: {str(e)}")
            return ("", "")
    
    def get_name_from_ip(self, ip: str) -> str:
        """Get the hostname/name for the given IP address."""
        try:
            for (stored_ip, mac), name in self.ipsList.items():
                if stored_ip == ip:
                    return name
            return self._resolve_hostname(ip)
        except Exception as e:
            print(f"Error getting name for IP: {str(e)}")
            return ""
    
    def return_ipsList(self) -> dict[tuple[str, str], str]:
        """Return the complete list of discovered devices."""
        return self.ipsList
    
    def _get_mac_for_ip(self, ip: str) -> str:
        """Get MAC address for IP using ARP request."""
        try:
            arp_request = ARP(pdst=ip)
            broadcast = Ether(dst="ff:ff:ff:ff:ff:ff")
            arp_request_broadcast = broadcast / arp_request
            answered_list = srp(arp_request_broadcast, timeout=2, verbose=False)[0]
            if answered_list:
                return answered_list[0][1].hwsrc
            return ""
        except Exception as e:
            return ""
    
    def _get_ip_for_mac(self, mac: str) -> str:
        """Get IP address for MAC (limited functionality)."""
        try:
            for (ip, stored_mac), name in self.ipsList.items():
                if stored_mac.lower() == mac.lower():
                    return ip
            return ""
        except Exception as e:
            return ""
    
    def _resolve_hostname(self, ip: str) -> str:
        """Resolve hostname for IP address."""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname
        except (socket.herror, socket.gaierror):
            return f"Unknown-{ip}"
        except Exception as e:
            return f"Device-{ip}"
    
    def print_discovered_devices(self) -> None:
        """Print all discovered devices in a formatted way."""
        print("\n=== Discovered Devices ===")
        if not self.ipsList:
            print("No devices discovered yet.")
            return
        
        print(f"{'IP Address':<15} {'MAC Address':<17} {'Hostname'}")
        print("-" * 60)
        
        for (ip, mac), name in self.ipsList.items():
            print(f"{ip:<15} {mac:<17} {name}")
        
        print(f"\nTotal devices: {len(self.ipsList)}")